export enum Status {
    IDLE=0,
    BOOKED=1,
    ON_TRIP=2
}
